﻿namespace AdvertisingCampaign.Model
{
    public class Ad
    {
        public int Id { get; set; }
        public int CampaignId { get; set; }
        public string Title { get; set; }
        public string ContentUrl { get; set; }
    }
}
