﻿using AdvertisingCampaign.Data;
using AdvertisingCampaign.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AdvertisingCampaign.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CampaignController : ControllerBase
    {

        private readonly DBContext _context;

        public CampaignController(DBContext context)
        {
            _context = context;


        }

        [HttpGet]
        public async Task<IEnumerable<Campaign>> Get()
        {
            return await _context.Campaign.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            if (id < 1)
                return BadRequest();
            var campaign = await _context.Campaign.FirstOrDefaultAsync(m => m.Id == id);
            if (campaign == null)
                return NotFound();
            return Ok(campaign);

        }
        //[Route("/campaignid/ads")]
        //[HttpGet("{id}")]
        //public async Task<IActionResult> Getad(int id)
        //{
        //    if (id < 1)
        //        return BadRequest();
        //    var add = await _context.ad.FirstOrDefaultAsync(m => m.Id == id);
        //    if (add == null)
        //        return NotFound();
        //    return Ok(add);
        //}

        [HttpPost]
        public async Task<IActionResult> Post(Campaign campaign)
        {
            _context.Add(campaign);
            await _context.SaveChangesAsync();
            return Ok();
        }
        [Route("/ads")]
        [HttpPost]
        public async Task<IActionResult> Post(Ad ad)
        {
            _context.Add(ad);
            await _context.SaveChangesAsync();
            return Ok();
        }
        [HttpPut]
        public async Task<IActionResult> Put(Campaign campaign)
        {
            if (campaign == null || campaign.Id == 0)
                return BadRequest();

            var product = await _context.Campaign.FindAsync(campaign.Id);
            if (product == null)
                return NotFound();
            product.Name = campaign.Name;
            product.StartDate = campaign.StartDate;
            product.EndDate = campaign.EndDate;
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (id < 1)
                return BadRequest();
            var campaign = await _context.Campaign.FindAsync(id);
            if (campaign == null)
                return NotFound();
            _context.Campaign.Remove(campaign);
            await _context.SaveChangesAsync();
            return Ok();

        }


    }
}
