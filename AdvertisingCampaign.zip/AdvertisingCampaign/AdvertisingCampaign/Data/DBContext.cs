﻿using AdvertisingCampaign.Model;
using Microsoft.EntityFrameworkCore;

namespace AdvertisingCampaign.Data
{
    public class DBContext : DbContext
    {

        public DBContext(DbContextOptions<DBContext> options) : base(options)
        {
            
        }

        public DbSet<Campaign> Campaign { get; set; }
        public DbSet<Ad> ad { get; set; }



    }
}
